﻿namespace StellarSync.Synchronization.Entity {
    internal class Mod {
        public ulong WorkshopId { get; set; }
        public required string Name { get; set; }
    }
}
